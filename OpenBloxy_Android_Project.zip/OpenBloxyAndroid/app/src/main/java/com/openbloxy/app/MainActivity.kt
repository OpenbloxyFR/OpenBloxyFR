package com.openbloxy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val Navy = Color(0xFF07152F)
private val Blue = Color(0xFF145BFF)
private val Pale = Color(0xFFEAF2FF)
private val Ink = Color(0xFF152544)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = BloxyStore(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color(0xFFF7FAFF))) {
                BloxyApp(store)
            }
        }
    }
}

@Composable
private fun BloxyApp(store: BloxyStore) {
    val scope = rememberCoroutineScope()
    var messages by remember { mutableStateOf(store.loadMessages()) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf(store.getApiKey()) }
    var model by remember { mutableStateOf(store.getModel()) }

    if (settings) {
        Column(Modifier.fillMaxSize().background(Color(0xFFF7FAFF)).padding(20.dp)) {
            TextButton(onClick = { settings = false }) { Text("← Back") }
            Text("Settings", style = MaterialTheme.typography.headlineMedium, color = Navy)
            Spacer(Modifier.height(18.dp))
            Text("OpenAI API key")
            OutlinedTextField(
                value = key, onValueChange = { key = it }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                placeholder = { Text("sk-…") }
            )
            Spacer(Modifier.height(16.dp))
            Text("Model ID")
            OutlinedTextField(value = model, onValueChange = { model = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            Text("Default: gpt-6.2-sol. Your API account must have access to the selected model.",
                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            Spacer(Modifier.height(20.dp))
            Button(onClick = {
                store.saveApiKey(key.trim())
                store.saveModel(model.trim().ifBlank { "gpt-6.2-sol" })
                settings = false
            }, modifier = Modifier.fillMaxWidth()) { Text("Save settings") }
            Spacer(Modifier.height(12.dp))
            Text("Prototype warning: the key is stored in app-private preferences, not encrypted. Do not distribute this build with a shared production key. Public release needs a secure backend proxy.",
                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFF7FAFF))) {
        Row(
            Modifier.fillMaxWidth().background(Navy).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("OpenBloxy", color = Color(0xFF91C8FF), style = MaterialTheme.typography.labelLarge)
                Text("BLOXY AI", color = Color.White, style = MaterialTheme.typography.titleLarge)
            }
            IconButton(onClick = {
                messages = emptyList(); store.saveMessages(messages); errorText = null
            }) { Icon(Icons.Default.Add, "New chat", tint = Color.White) }
            IconButton(onClick = { settings = true }) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }

        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Text("✦", color = Blue, style = MaterialTheme.typography.displayLarge)
                Text("Hey, I'm Bloxy.", color = Navy, style = MaterialTheme.typography.headlineMedium)
                Text("Your OpenBloxy AI assistant. Ask me anything.", color = Color.Gray)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { MessageBubble(it) }
                if (busy) item { Text("Bloxy is thinking…", color = Blue) }
            }
        }

        errorText?.let { Text(it, color = Color(0xFFB42318), modifier = Modifier.padding(horizontal = 16.dp)) }

        Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = draft, onValueChange = { draft = it },
                modifier = Modifier.weight(1f).background(Pale, RoundedCornerShape(22.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                enabled = !busy,
                decorationBox = { inner ->
                    if (draft.isEmpty()) Text("Message Bloxy…", color = Color.Gray)
                    inner()
                }
            )
            IconButton(enabled = !busy && draft.isNotBlank(), onClick = {
                val prompt = draft.trim()
                draft = ""
                errorText = null
                val sentHistory = messages + ChatMessage("user", prompt)
                messages = sentHistory
                store.saveMessages(sentHistory)
                busy = true
                scope.launch {
                    try {
                        val answer = OpenAiResponses(store.getApiKey(), store.getModel()).reply(sentHistory)
                        messages = messages + ChatMessage("assistant", answer)
                        store.saveMessages(messages)
                    } catch (e: Exception) {
                        errorText = e.message ?: "Request failed. Please try again."
                    } finally { busy = false }
                }
            }) { Icon(Icons.Default.Send, "Send", tint = Blue) }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 320.dp)
            .background(if (user) Blue else Color.White, RoundedCornerShape(18.dp)).padding(14.dp)) {
            Text(if (user) "You" else "Bloxy",
                color = if (user) Color(0xFFDCEAFF) else Blue,
                style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            Text(message.text, color = if (user) Color.White else Ink)
        }
    }
}
