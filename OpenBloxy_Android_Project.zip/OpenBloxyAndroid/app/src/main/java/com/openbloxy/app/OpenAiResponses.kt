package com.openbloxy.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class OpenAiResponses(private val apiKey: String, private val model: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .callTimeout(120, TimeUnit.SECONDS).build()

    suspend fun reply(history: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) error("Add your OpenAI API key in Settings first.")
        val input = JSONArray()
        history.takeLast(20).forEach { m ->
            input.put(JSONObject().put("role", m.role).put("content", m.text))
        }
        val bodyJson = JSONObject()
            .put("model", model.ifBlank { "gpt-6.2-sol" })
            .put("instructions", SYSTEM_PROMPT)
            .put("input", input)
            .put("max_output_tokens", 1200)
        val request = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = try { JSONObject(raw).optJSONObject("error")?.optString("message") }
                    catch (_: Exception) { null }
                error(when (response.code) {
                    401 -> "API key rejected (401). Check your key in Settings."
                    429 -> "Rate limit or quota reached (429). Try again later."
                    else -> "OpenAI API error (${response.code}): ${detail ?: raw.take(250)}"
                })
            }
            val output = JSONObject(raw).optJSONArray("output") ?: JSONArray()
            val text = mutableListOf<String>()
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                if (item.optString("type") != "message") continue
                val parts = item.optJSONArray("content") ?: continue
                for (j in 0 until parts.length()) {
                    val part = parts.optJSONObject(j) ?: continue
                    if (part.optString("type") == "output_text") text += part.optString("text")
                }
            }
            text.joinToString("\n").trim().ifBlank {
                error("The API returned no text. Check the selected model and API response.")
            }
        }
    }

    companion object {
        private const val SYSTEM_PROMPT = "You are Bloxy, the friendly and capable AI assistant created for OpenBloxy. " +
            "Be natural, patient, intelligent, and direct. Adapt detail to the question and respond in the user's language. " +
            "Explain complex subjects clearly and use Markdown when useful. Be honest about uncertainty. " +
            "Never invent facts or claim to have completed actions you did not perform. " +
            "Do not claim to be ChatGPT or to access proprietary model internals."
    }
}
