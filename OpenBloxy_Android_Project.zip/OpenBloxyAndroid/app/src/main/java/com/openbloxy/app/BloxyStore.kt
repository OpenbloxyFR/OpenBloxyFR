package com.openbloxy.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class BloxyStore(context: Context) {
    private val prefs = context.getSharedPreferences("bloxy_local", Context.MODE_PRIVATE)
    fun getApiKey() = prefs.getString("api_key", "") ?: ""
    fun saveApiKey(value: String) { prefs.edit().putString("api_key", value).apply() }
    fun getModel() = prefs.getString("model", "gpt-6.2-sol") ?: "gpt-6.2-sol"
    fun saveModel(value: String) { prefs.edit().putString("model", value).apply() }
    fun saveMessages(messages: List<ChatMessage>) {
        val a = JSONArray()
        messages.forEach { a.put(JSONObject().put("role", it.role).put("text", it.text)) }
        prefs.edit().putString("messages", a.toString()).apply()
    }
    fun loadMessages(): List<ChatMessage> = try {
        val a = JSONArray(prefs.getString("messages", "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            ChatMessage(o.getString("role"), o.getString("text"))
        }
    } catch (_: Exception) { emptyList() }
}
