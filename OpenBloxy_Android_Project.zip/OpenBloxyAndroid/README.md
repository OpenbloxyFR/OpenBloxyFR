# OpenBloxy Android — native APK project

Native Kotlin + Jetpack Compose Android app. Not a Pydroid/Python app.

## Current first milestone
- Native Android chat screen with OpenBloxy blue/navy styling
- Model and API-key settings
- Real OpenAI Responses API request at `POST /v1/responses`
- Locally saved chat transcript
- Real network/authentication/rate-limit error messages
- GitHub Actions workflow to build a debug APK

## Known unfinished features
Streaming, Room-based multi-conversation history, user-approved memory controls, export, encrypted credential storage, polished logo integration, and production backend proxy are future stages. This is not yet the final product.

The requested default model `gpt-6.2-sol` is configurable, but must be enabled for your API account. If unavailable, set an available model in Settings; the app displays the actual API error instead of faking a response.

## Build without Android Studio on your phone
1. Create a GitHub repository named `OpenBloxy`.
2. Upload all project files to the repository's `main` branch.
3. Open the repository's **Actions** tab.
4. Run **Build Bloxy APK**.
5. Download the `Bloxy-debug-apk` artifact from the completed workflow.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Local Linux build
Requires JDK 17, Android SDK platform 35/build tools 35, and Gradle 8.9.
Run `gradle wrapper --gradle-version 8.9`, then `./gradlew assembleDebug`.
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## API key warning
For prototype testing, the API key is stored in app-private SharedPreferences, which is not encrypted. Never commit it or distribute a shared production key. A public release must route requests through a secure backend proxy.
